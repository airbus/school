# Powershell Module

- Leader: Yves Campmas
- Volume: 6h 
- 100% on site
- Course: 60%
- Labs/HandOn: 40%

## Chapters

- [Presentation and History](01_presentation/)
- [Python basics](02_python-basics/)
- [Python advanced](03_python-advanced/)
- [Essential libraries](04_essential-libs/)
- [Cybersec Tools](05_cybersec-tools/)
# Get all services running
# How many do you have partition in your system ? Get the second local partition in your system
# Get Permission on the your home and convert to json
# Find in your system all files greather than 300 MB
# Write a function to check if a number is odd (check also the parameters)
# Change the screensaver timeout to 20 min in registry
# Get the 20 last error in your system quickly
# Find you login in Airbus Active Directory (hint: use ADSI and eu.airbus.corp)
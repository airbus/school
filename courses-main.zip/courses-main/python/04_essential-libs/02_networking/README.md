# Module: Networking

## Modules

- [Requests](01_requests.ipynb)
- [Flask](02_flask.ipynb)
- [FastAPI](03_fastapi.ipynb)

### How to set up and launch the notebook?

> bash ../../setup.sh
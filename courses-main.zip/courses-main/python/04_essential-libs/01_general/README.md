# Module: General

## Modules

- [Click](01_click.ipynb)
- [Collections](02_collections.ipynb)
- [Loguru](03_loguru.ipynb)
- [Threading](04_threading.ipynb)
- [Boto](05_boto.ipynb)

### How to set up and launch the notebook?

> bash ../../setup.sh
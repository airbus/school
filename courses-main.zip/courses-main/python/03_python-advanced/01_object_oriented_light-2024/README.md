# Object oriented programming - A Gentle Introduction

In this course, we'll be discovering how Python deals with OOP.

_**This is just a taste of OOP in Python.**_

---

Since the beginning of this course, you've been writing Python code using functions and variables.

---

But now we're going to explore a powerful way to structure your programs:

> by thinking in terms of **objects**.

---

Think of objects like blueprints for creating things.  

---

A blueprint tells you everything you need to know to build a house: what rooms it has, the materials used, and how everything fits together. 

---

In OOP, we create "blueprints" called **classes** to define our objects. 

---

Let's dive into the basics ...

## Classes and Objects

---

### Class

A template or blueprint that defines the structure and behavior of an object. 

It specifies what attributes (characteristics) an object will have and what methods (actions) it can perform.

---

### Object

An instance of a class. 

Think of it as a specific realization of the blueprint. 

---

### Example

Imagine you want to represent a `dog` in your code

You could create a `Dog` class with attributes like `name`, `age`, and `breed`. 

---

This is your blueprint or template for `dog`:

```python
class Dog:  # Defining the 'Dog' class
    def __init__(self, name, breed): # Special method called constructor
        self.name = name   # Attributes - characteristics of the dog
        self.breed = breed 

    def speak(self):  # Method - action the dog can perform
        print("Woof!")
```

Now that you've defined a blueprint for `dog`, you can create as many dogs **objects** as you want:

---

```python
# Creating objects (instances) of the Dog class:
sparky = Dog("Sparky", "Golden Retriever") # Object 'sparky' is created
buddy = Dog("Buddy", "Labrador")     # Another object 'buddy' 

print(sparky.name)  # Accessing attributes -> Output: Sparky
buddy.speak()        # Calling a method -> Output: Woof!
```

---

## Key Concepts

---

### Attributes (Variables)

These define the data associated with an object, like `name` and `breed` in our `Dog` example. 

They store information about the object's state.

---

### Methods (Functions)

These are functions defined within a class that operate on the object's attributes. 

They define the object's behavior, like the `bark()` method.

---

### `self`

A special keyword used inside class methods to refer to the current instance of the class. 

It allows you to access and modify the object's attributes.

---

### Why OOP?

OOP brings several advantages:

- **Organization:** Structures code into logical units (classes), making it more manageable for large projects.
- **Reusability:** Classes can be reused multiple times, saving time and effort.
- **Encapsulation:** Bundles data and methods together, protecting data from accidental modification and improving code security.
- **Inheritance:** Allows you to create new classes that inherit properties and behaviors from existing ones, promoting code reuse and extensibility.

---

## Inheritance

Inheritance is a mechanism in OOP where a class can inherit attributes and methods from another class.

This allows you to create specialized classes that build on the functionality of their parent class, reducing code duplication and promoting reusability.

For instance, let's say that you also need to model cats in your program. 

---

You can create a new `Cat` class similar to our earlier `Dog`:

```python
class Cat:  # Defining the 'Cat' class
    def __init__(self, name, breed): # Special method called constructor
        self.name = name   # Attributes - characteristics of the cat
        self.breed = breed 

    def speak(self):  # Method - action the cat can perform
        print("Meowww!")
```

---

Now that you've defined a blueprint for `cat`, you can create as many cats **objects** as you want:

```python
# Creating objects (instances) of the Cat class:
berlioz = Dog("Berlioz", "Chartreux") # Object 'sparky' is created
buddy = Dog("Duchess", "Persian")     # Another object 'buddy' 

print(berlioz.name)  # Accessing attributes -> Output: Berlioz
buddy.speak()        # Calling a method -> Output: Meowww!
```

---

Despite this does work as expected, we can see that there is some code duplication.

Let's go one step further by creating a `Cat` class that inherits from the `Animal` class.

This class will act as a common ancestor for both `Dog` and `Cat`.

It's called a **base class** or **parent class**.

---

```python
class AnimalBase:  # Defining the 'Base' class
    def __init__(self, name, breed): # Special method called constructor
        self.name = name   # Attributes - characteristics of the animal
        self.breed = breed 

    def sleep(duration: int):
        print(f'{self.name} is sleeping for {duration} hours')

    @abstractmethod
    def speak(self):  # Abstract method - action the animal can perform
        ...
```

---

With that in place, it's now easy to refactor our 2 formers `Dog` and `Cat`classes:

```python
class Cat(AnimalBase):  # the 'Cat' class inherits from AnimalBase
    def __init__(self, name, breed): 
        super().__init__(name=name, breed=breed)  # here we call the parent's __init__() method

    def speak(self):        # Here we define a concrete implementation for the speak() method
        print("Meowww!")    # in OOP this is called "overriding the base method" 
```

---

And so the `Dog`...

```python
class Dog(AnimalBase):  # the 'Dog' class inherits from AnimalBase
    def __init__(self, name, breed): 
        super().__init__(name=name, breed=breed)  # here we call the parent's __init__() method

    def speak(self):        # Here we define a concrete implementation for the speak() method
        print("Woof!")      # in OOP this is called "overriding the base method" 
```

---

Aside from the classes definitions, the rest of the code remains unchanged following the inheritance implementation:

```python
sparky = Dog("Sparky", "Golden Retriever")
sparky.speak()        # Calling a method -> Output: Woof! (it's a dog)

berlioz = Cat("Berlioz", "Chartreux") # Object 'berlioz' is created, it's a cat
berlioz(berlioz.name)  # Accessing attributes -> Output: Berlioz
berlioz.speak()        # Calling a method -> Output: Meowww! (indeed)
```

---

> the `speak()` method is inherited from the base class and overridden in the child classes to specialize it for each animal type.

---

Because we defined a `sleep()` method in the base `AnimalClass`, and because all animals sleep the same way, there is no need to override it in the child classes.

Having `sleep()` method in the base `AnimalClass` is sufficient to make sure that all animal objects have this behavior:

---

```python
sparky.sleep(2)          # Calling a method -> Output: Sparky is sleeping for 2 hours
berlioz.sleep(3)         # Calling a method -> Output: Berlioz is sleeping for 3 hours
```
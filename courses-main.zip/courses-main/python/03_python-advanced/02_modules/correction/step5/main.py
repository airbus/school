import sys

if __name__ == "__main__":
    print("profile is ", str(sys.getprofile()))
    print(sys.gettemperature())

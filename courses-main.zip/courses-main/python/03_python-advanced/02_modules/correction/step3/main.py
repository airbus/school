import greetings as g

if __name__ == "__main__":
    g.say_something("Hello World")
